package com.app.curdDemo.service;

public class StudentServiceImpl implements StudentService {

}
