package com.app.curdDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.curdDemo.model.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Integer> {

}
