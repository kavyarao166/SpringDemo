package com.app.curdDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

@SuppressWarnings("rawtypes")
public interface ClassRepository extends JpaRepository<Class, Integer> {

}
