package com.app.curdDemo.service;

public interface ClassService {

}
