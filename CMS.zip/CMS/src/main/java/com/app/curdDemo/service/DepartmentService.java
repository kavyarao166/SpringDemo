package com.app.curdDemo.service;

public interface DepartmentService {

}
