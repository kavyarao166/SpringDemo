package com.app.curdDemo.model;

import java.util.Arrays;

public class Teacher {
	
	private int id;
	
	private String title;
	
	private String gender;
	
	private int age;
	
	private String[] address;
	
	private int classId;
	
	private int salary;
	
	private String department;

	public Teacher() {
		
	}
	
	public Teacher(int id, String title, String gender, int age, String[] address, int classId, int salary,
			String department) {
		
		this.id = id;
		this.title = title;
		this.gender = gender;
		this.age = age;
		this.address = address;
		this.classId = classId;
		this.salary = salary;
		this.department = department;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String[] getAddress() {
		return address;
	}

	public void setAddress(String[] address) {
		this.address = address;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Teacher [id=" + id + ", title=" + title + ", gender=" + gender + ", age=" + age + ", address="
				+ Arrays.toString(address) + ", classId=" + classId + ", salary=" + salary + ", department="
				+ department + "]";
	}
	
}
