package com.app.curdDemo.model;

import javax.persistence.Column;

public class Department {

	@Column(name="dept_id")
	private int dept_id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="HOD")
	private String hod;
	
	@Column(name="location")
	private String location;
	
	public Department() {
		
	}

	public Department(int dept_id, String name, String hod, String location) {
		
		this.dept_id = dept_id;
		this.name = name;
		this.hod = hod;
		this.location = location;
	}

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHod() {
		return hod;
	}

	public void setHod(String hod) {
		this.hod = hod;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Department [dept_id=" + dept_id + ", name=" + name + ", hod=" + hod + ", location=" + location + "]";
	}
	
}
