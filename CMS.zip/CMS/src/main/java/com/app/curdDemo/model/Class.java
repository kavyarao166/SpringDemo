package com.app.curdDemo.model;

import javax.persistence.Column;

public class Class {

	@Column(name="class_id")
	private int class_id;
	
	@Column(name="name")
	private String name;
	
	public Class() {
		
	}

	public Class(int class_id, String name) {
		super();
		this.class_id = class_id;
		this.name = name;
	}

	public int getClass_id() {
		return class_id;
	}

	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Class [class_id=" + class_id + ", name=" + name + "]";
	}
}
