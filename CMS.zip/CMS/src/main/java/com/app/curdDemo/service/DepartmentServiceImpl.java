package com.app.curdDemo.service;

public class DepartmentServiceImpl implements DepartmentService {

}
