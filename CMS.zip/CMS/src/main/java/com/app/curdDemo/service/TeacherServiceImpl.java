package com.app.curdDemo.service;

public class TeacherServiceImpl implements TeacherService {

}
