package com.app.curdDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.curdDemo.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
