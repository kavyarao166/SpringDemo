package com.app.curdDemo.model;

import javax.persistence.Column;

public class Student {

	@Column(name="Reg_no")
	private int reg_no;
	
	@Column(name="name")
	private String name;
	
	@Column(name="class")
	private String student_class;
	
	public Student() {
		
	}

	public Student(int reg_no, String name, String student_class) {
		
		this.reg_no = reg_no;
		this.name = name;
		this.student_class = student_class;
	}

	public int getReg_no() {
		return reg_no;
	}

	public void setReg_no(int reg_no) {
		this.reg_no = reg_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStudent_class() {
		return student_class;
	}

	public void setStudent_class(String student_class) {
		this.student_class = student_class;
	}

	@Override
	public String toString() {
		return "Student [reg_no=" + reg_no + ", name=" + name + ", student_class=" + student_class + "]";
	}
	
}
