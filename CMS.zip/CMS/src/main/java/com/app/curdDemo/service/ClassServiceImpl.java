package com.app.curdDemo.service;

public class ClassServiceImpl implements ClassService {

}
